import 'package:flutter/material.dart';
import 'package:lyra/pages/home.dart';
import 'package:lyra/pages/profile.dart';
import 'package:lyra/pages/settings.dart';

class IndexPage extends StatefulWidget {
  const IndexPage ({super.key});

  @override
  State<IndexPage> createState() => _IndexPageState();
}

class _IndexPageState extends State<IndexPage> {
  int _selectedIndex = 0;

  void bottomnavbarTapped(int index){
    setState(() {
      _selectedIndex = index;
    });
  
  }

  final List _pages = [
    HomePage(),

    SettingsPage(),

    ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 49, 89, 208),
        centerTitle: true,
        title: Text("lyra page", style: TextStyle(color: const Color.fromARGB(255, 106, 167, 225), fontSize: 25, fontWeight: FontWeight.bold),),
        actions: [IconButton(onPressed: (){}, icon: Icon(Icons.notifications))],
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: bottomnavbarTapped,
        items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "home"),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: "settings"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "profile"),
      ]),

      body: _pages[_selectedIndex],
    );
  }
}