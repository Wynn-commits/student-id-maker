import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(padding: EdgeInsets.all(10)),

          Text("Home Page", style: TextStyle(fontSize: 20),),

          Container(
            height: 500,
            color: Colors.deepPurple,
          ),

          Container(
            height: 500,
            color: Colors.lime,
          ),
        ],
      ),
    );
  }
}