import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
       return Scaffold(
      body: Center(
        child: Column(
          children: [
            CircleAvatar(
              radius: 100,
              backgroundImage: AssetImage("../assets/lyra.jpg"),
            ),
            Text("Lyra Judiana", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
            Text("Age: 20", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            Text("Address: So. Lawis Brgy. Buluangan, San Carlos City", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)
          ],
        ),
      ),
    );
  }
}