import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
       return Scaffold(
      body: Center(
        child: Column(
          children: [
            CircleAvatar(
              radius: 100,
              backgroundImage: AssetImage("../assets/piala.jpg"),
            ),
            Text("Angeline  Piala", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            Text("Age: 23", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),),
            Text("Address: So.Tuburan Brgy. Buluangan", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),)
          ],
        ),
      ),
    );
  }
}