import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(padding: EdgeInsets.all(10)),

          Text("Home Page", style: TextStyle(fontSize: 20),),

          Container(
            height: 500,
            color: const Color.fromARGB(255, 48, 184, 234),
          ),

          Container(
            height: 200,
            color: const Color.fromARGB(255, 198, 7, 227),
          ),
          Container(
            height: 500,
            color: const Color.fromARGB(255, 148, 241, 151),
          ),
        ],
      ),
    );
  }
}