import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 200,
              color: const Color.fromARGB(255, 198, 7, 227),
              child: Column(
                children: [
                  Icon(Icons.settings, size: 50, color: const Color.fromARGB(255, 196, 227, 243),),
                  Text("Settings Page ni", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                ],
              ),
          ),
          ],
        ),
      ),
    );
  }
}