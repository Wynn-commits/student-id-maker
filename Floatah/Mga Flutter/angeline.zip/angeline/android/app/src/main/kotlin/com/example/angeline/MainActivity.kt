package com.example.angeline

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
