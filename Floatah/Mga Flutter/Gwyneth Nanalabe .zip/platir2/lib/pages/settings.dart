import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ListView(
        padding: EdgeInsets.all(15),
        children: [
          Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.person), color: Colors.blue[700]),
                  title: Text("Account Settings"),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.notifications), color: Colors.blue[600]),
                  title: Text("Notifications"),
                  trailing: Switch(value: (true), onChanged: (_){}),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.shield), color: Colors.blue[500]),
                  title: Text("Privacy"),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.lock), color: Colors.blue[400]),
                  title: Text("Security"),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.language), color: Colors.blue[300]),
                  title: Text("Language"),
                  trailing: Icon(Icons.arrow_forward_ios),
                ),
              ),
              SizedBox(height: 10,),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Color.fromARGB(255, 34, 149, 244), blurRadius: 6),
                  ]
                ),
                child: ListTile(
                  leading: Icon((Icons.dark_mode), color: Colors.blue[200]),
                  title: Text("Dark Mode"),
                  trailing: Switch(value: (true), onChanged: (_){}),
                ),
              ),
              SizedBox(height: 30,),
              ElevatedButton(
                onPressed: (){}, 
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[800],
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 10)
                ), 
                child: Text(
                  "Log Out", 
                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                )
              )
            ],
          ),
        ],
      ),
    );
  }
}
