import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          Center(
  child: ClipOval(
    child: Image.asset(
      "../assets/gwyn.jpg",
      width: 150,   // diameter = 2 * radius
      height: 150,
      fit: BoxFit.cover, // makes the image fill/cover the circle
    ),
  ),
),

          SizedBox(height: 20,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Gwyneth Nanalabe", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),),
              Text("gwyn@gmail.com", style: TextStyle(color: Colors.grey),)
            ],
          ),
          SizedBox(height: 20,),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[600],
              padding: EdgeInsets.symmetric(horizontal: 50, vertical: 10),
            ),
            onPressed: (){}, 
            child: Text("Edit Profile", style: TextStyle(color: Colors.white, fontSize: 17),),
          ),
          SizedBox(height: 20,),
          Container(
            padding: EdgeInsets.all(15),
            height: 250,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),

              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 34, 149, 244),
                  blurRadius: 4,
                ),
              ]
            ),

            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ListTile(
                  leading: Icon(Icons.phone, color: Colors.blue[700], size: 26,),
                  title: Text("Phone"),
                  subtitle: Text("+63987643210"),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16,),
                ),
                ListTile(
                  leading: Icon(Icons.date_range, color: Colors.blue[500], size: 26,),
                  title: Text("Birthdate"),
                  subtitle: Text("January 15, 1995"),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16,),
                ),
                ListTile(
                  leading: Icon(Icons.location_city, color: Colors.blue[400], size: 26,),
                  title: Text("Location"),
                  subtitle: Text("Tapad Silingan"),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16,),
                ),
              ],
            ),
          ),

          SizedBox(height: 20,),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[800],
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
            ),
            onPressed: (){}, 
            child: Text("Log Out", style: TextStyle(color: Colors.white),))
        ],
      ),
    );
  }
}
