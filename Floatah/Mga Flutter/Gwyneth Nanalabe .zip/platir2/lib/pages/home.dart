import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ListView(
        padding: EdgeInsets.all(10),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: [
                  Text("Welcome to Gwyn!", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                  Text("This is my Home Page!", style: TextStyle(color: Colors.grey)),
                ],
              ),
            ],
          ),
          SizedBox(height: 50),

          // Productivity Tools
          Container(
            padding: EdgeInsets.all(20),
            height: 200,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.blue, blurRadius: 6)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Productivity Tools", style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.bold)),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [Icon(Icons.note, color: Colors.blue[700], size: 50), Text("Notes")]),
                    Column(children: [Icon(Icons.calendar_today, color: Colors.blue[400], size: 50), Text("Calendar")]),
                    Column(children: [Icon(Icons.task, color: Colors.lightBlue, size: 50), Text("Tasks")]),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 30),

          // Recent Activity
          Container(
            padding: EdgeInsets.all(20),
            height: 200,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.blue, blurRadius: 6)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Recent Activity", style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.bold)),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [Icon(Icons.message, color: Colors.blue[600], size: 50), Text("Messages")]),
                    Column(children: [Icon(Icons.notifications, color: Colors.blue[300], size: 50), Text("Alerts")]),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 30),

          // Statistics
          Container(
            padding: EdgeInsets.all(20),
            height: 200,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: Colors.blue, blurRadius: 6)],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Statistics", style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.bold)),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [Icon(Icons.bar_chart, color: Colors.blue[700], size: 50), Text("Progress")]),
                    Column(children: [Icon(Icons.trending_up, color: Colors.blue[400], size: 50), Text("Growth")]),
                    Column(children: [Icon(Icons.pie_chart, color: Colors.lightBlue, size: 50), Text("Reports")]),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
