import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text(
            "Welcome to the Home Page!",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Text("Ambot unsay e butnag nako dri", textAlign: TextAlign.center,), 
          SizedBox(height: 20),
          Text("Scroll down lang lihog", textAlign: TextAlign.center,),
          Container(
            width: 200,
            height: 1000,
            decoration: BoxDecoration(
              color: Colors.black,
            ),
            child: Icon(Icons.diamond, size: 50, color: Colors.white,),
          ),
          Text("Labyu sir", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 50), textAlign: TextAlign.center,),
        ],
      ),
    );
  }
}
