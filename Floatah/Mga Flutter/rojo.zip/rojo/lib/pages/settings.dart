import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.settings, size: 60, color: const Color.fromARGB(255, 53, 0, 246)),
            SizedBox(height: 20),
            Text("Settings Page", style: TextStyle(fontSize: 24)),
            SizedBox(height: 10),
            Text("Wala pay settings"),
          ],
        ),
      ),
    );
  }
}