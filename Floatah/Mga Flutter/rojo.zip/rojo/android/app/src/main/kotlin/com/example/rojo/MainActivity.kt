package com.example.rojo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
