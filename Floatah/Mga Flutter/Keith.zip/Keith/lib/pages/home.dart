import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text("Chess Shop"),
        backgroundColor: Colors.black,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Header
          const Text(
            "Welcome to the Chess Shop",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Boards, pieces, and sets for every player",
            style: TextStyle(color: Colors.black54),
          ),

          const SizedBox(height: 24),

          // Featured Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Featured Items",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Chess Board
                    Column(
                      children: [
                        Icon(Icons.grid_on, size: 50, color: Colors.amber),
                        SizedBox(height: 6),
                        Text("Chess Board"),
                      ],
                    ),
                    // Chess Pieces
                    Column(
                      children: [
                        Icon(Icons.extension, size: 50, color: Colors.amber),
                        SizedBox(height: 6),
                        Text("Chess Pieces"),
                      ],
                    ),
                    // Chess Clock
                    Column(
                      children: [
                        Icon(Icons.access_time, size: 50, color: Colors.amber),
                        SizedBox(height: 6),
                        Text("Chess Clock"),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Simple Category Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Categories",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 12),
                Text("• Wooden Boards"),
                Text("• Tournament Sets"),
                Text("• Digital Clocks"),
                Text("• Beginner Kits"),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
