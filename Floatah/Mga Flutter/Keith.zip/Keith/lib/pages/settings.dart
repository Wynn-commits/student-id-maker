import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text("Settings"),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Account Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "Account",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 12),
                ListTile(
                  leading: Icon(Icons.person, color: Colors.amber),
                  title: Text("Account Settings"),
                ),
                ListTile(
                  leading: Icon(Icons.shield, color: Colors.amber),
                  title: Text("Privacy"),
                ),
                ListTile(
                  leading: Icon(Icons.lock, color: Colors.amber),
                  title: Text("Security"),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Preferences Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Preferences",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.notifications, color: Colors.amber),
                  title: const Text("Notifications"),
                  trailing: Switch(value: true, onChanged: (_) {}),
                ),
                ListTile(
                  leading: const Icon(Icons.language, color: Colors.amber),
                  title: const Text("Language"),
                ),
                ListTile(
                  leading: const Icon(Icons.dark_mode, color: Colors.amber),
                  title: const Text("Dark Mode"),
                  trailing: Switch(value: false, onChanged: (_) {}),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Log Out Button
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text(
              "Log Out",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
