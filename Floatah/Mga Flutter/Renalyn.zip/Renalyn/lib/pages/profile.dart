import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(252, 228, 236, 1),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            // Profile card
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: LinearGradient(
                  colors: [
                    Color.fromRGBO(240, 98, 146, 1),
                    Color.fromRGBO(233, 30, 99, 1),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(4, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    padding: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        "../assets/images/Renalyn.jpg",
                        width: 120,
                        height: 120,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(height: 14),
                  Text(
                    "Renalyn Pataytay",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text("RenaSkirts@gmail.com", style: TextStyle(color: Colors.white70)),
                  SizedBox(height: 12),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.star, size: 16, color: Colors.white),
                        SizedBox(width: 6),
                        Text(
                          "VIP Member",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Orders
                      Column(
                        children: [
                          Text(
                            "12",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text("Orders", style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                      Container(height: 40, width: 1, color: Colors.white38),
                      // Wishlist
                      Column(
                        children: [
                          Text(
                            "8",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text("Wishlist", style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                      Container(height: 40, width: 1, color: Colors.white38),
                      // Points
                      Column(
                        children: [
                          Text(
                            "1,250",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text("Points", style: TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // My Measurementz
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "My Measurements",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(173, 20, 87, 1),
                        ),
                      ),
                      Text(
                        "Size Guide",
                        style: TextStyle(
                          color: Color.fromRGBO(233, 30, 99, 1),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      // Waist
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: Color.fromRGBO(233, 30, 99, 0.12),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.straighten, color: Color.fromRGBO(233, 30, 99, 1)),
                              SizedBox(height: 6),
                              Text(
                                "26\"",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(173, 20, 87, 1),
                                ),
                              ),
                              Text("Waist", style: TextStyle(fontSize: 12, color: Colors.black54)),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      // Hips
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: Color.fromRGBO(233, 30, 99, 0.12),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.straighten, color: Color.fromRGBO(233, 30, 99, 1)),
                              SizedBox(height: 6),
                              Text(
                                "36\"",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(173, 20, 87, 1),
                                ),
                              ),
                              Text("Hips", style: TextStyle(fontSize: 12, color: Colors.black54)),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      // Size
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: Color.fromRGBO(233, 30, 99, 0.12),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            children: [
                              Icon(Icons.checkroom, color: Color.fromRGBO(233, 30, 99, 1)),
                              SizedBox(height: 6),
                              Text(
                                "M",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(173, 20, 87, 1),
                                ),
                              ),
                              Text("Size", style: TextStyle(fontSize: 12, color: Colors.black54)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // About Me
            Container(
              padding: EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Phone
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.phone, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Phone", style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text("097463866571"),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Birthdate
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.cake, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Birthdate", style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text("April 23, 2005"),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Location
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.location_city, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Location", style: TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text("Guihulngan City"),
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Account menu
            Container(
              padding: EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // My Orders
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.shopping_bag, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("My Orders", style: TextStyle(fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Wishlist
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.favorite, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Wishlist", style: TextStyle(fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Saved Addresses
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.location_on, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Saved Addresses", style: TextStyle(fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Payment Methods
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.credit_card, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text("Payment Methods", style: TextStyle(fontWeight: FontWeight.w600)),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),

            // Edit Profile
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromRGBO(233, 30, 99, 1),
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                "Edit Profile",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            SizedBox(height: 12),

            // Log Out
            OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                side: BorderSide(color: Color.fromRGBO(233, 30, 99, 1), width: 1.5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                "Log Out",
                style: TextStyle(
                  color: Color.fromRGBO(233, 30, 99, 1),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}