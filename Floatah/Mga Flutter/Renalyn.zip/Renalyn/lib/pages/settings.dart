import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(252, 228, 236, 1),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            // Account section
            Text(
              "ACCOUNT",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: Color.fromRGBO(240, 98, 146, 1),
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Account Settings
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.person, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Account Settings",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Privacy
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.shield, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Privacy",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Security
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.lock, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Security",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Preferences section
            Text(
              "PREFERENCES",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: Color.fromRGBO(240, 98, 146, 1),
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Notifications
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.notifications, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Notifications",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Switch(
                      value: true,
                      onChanged: (_) {},
                      activeColor: Color.fromRGBO(233, 30, 99, 1),
                    ),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Language
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.language, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Language",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text("English", style: TextStyle(color: Colors.grey)),
                        Icon(Icons.chevron_right, color: Colors.grey),
                      ],
                    ),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Dark Mode
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.dark_mode, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Dark Mode",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Switch(
                      value: false,
                      onChanged: (_) {},
                      activeColor: Color.fromRGBO(233, 30, 99, 1),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Support section
            Text(
              "SUPPORT",
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                color: Color.fromRGBO(240, 98, 146, 1),
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Help Center
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.help, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Help Center",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                  Divider(height: 1, indent: 70, color: Color.fromRGBO(233, 30, 99, 0.12)),
                  // Terms
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Color.fromRGBO(233, 30, 99, 0.12),
                      child: Icon(Icons.description, color: Color.fromRGBO(233, 30, 99, 1)),
                    ),
                    title: Text(
                      "Terms & Conditions",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: Icon(Icons.chevron_right, color: Colors.grey),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),

            // Log Out
            OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                side: BorderSide(color: Color.fromRGBO(233, 30, 99, 1), width: 1.5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                "Log Out",
                style: TextStyle(
                  color: Color.fromRGBO(233, 30, 99, 1),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}