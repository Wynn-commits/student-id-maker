import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Title
          Text(
            "Vape Shop",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
          ),

          SizedBox(height: 16),

          // Search bar
          Container(
            padding: EdgeInsets.all(12),
            color: Color.fromRGBO(232, 245, 233, 1),
            child: Row(
              children: [
                Icon(Icons.search, color: Colors.green),
                SizedBox(width: 8),
                Text("Search", style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),

          SizedBox(height: 24),

          // Products title
          Text(
            "Products",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),

          SizedBox(height: 12),

          // Product 1
          Container(
            padding: EdgeInsets.all(12),
            color: Color.fromRGBO(232, 245, 233, 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Pod System Kit",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Text("₱1,299", style: TextStyle(color: Colors.green)),
                  ],
                ),
                Icon(Icons.add, color: Colors.green),
              ],
            ),
          ),

          SizedBox(height: 10),

          // Product 2
          Container(
            padding: EdgeInsets.all(12),
            color: Color.fromRGBO(232, 245, 233, 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Disposable Vape",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Text("₱450", style: TextStyle(color: Colors.green)),
                  ],
                ),
                Icon(Icons.add, color: Colors.green),
              ],
            ),
          ),

          SizedBox(height: 10),

          // Product 3
          Container(
            padding: EdgeInsets.all(12),
            color: Color.fromRGBO(232, 245, 233, 1),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "E-Liquid 30ml",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Text("₱350", style: TextStyle(color: Colors.green)),
                  ],
                ),
                Icon(Icons.add, color: Colors.green),
              ],
            ),
          ),
        ],
      ),
    );
  }
}