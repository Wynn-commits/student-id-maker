import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            // Title
            Text(
              "Profile",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),

            SizedBox(height: 24),

            // Profile info
            Container(
              padding: EdgeInsets.all(6),
              color: Color.fromRGBO(232, 245, 233, 1),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage("../assets/images/reyjon.jpg"),
                  ),
                  SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Reyjhon Dacumos",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text("ReyJhonGwapo@gmail.com", style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Details
            Text(
              "Details",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              color: Color.fromRGBO(232, 245, 233, 1),
              child: Column(
                children: [
                  // Phone
                  ListTile(
                    title: Text("Phone"),
                    subtitle: Text("09123456789"),
                  ),
                  // Location
                  ListTile(
                    title: Text("Location"),
                    subtitle: Text("Guihulngan City"),
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Menu
            Container(
              color: Color.fromRGBO(232, 245, 233, 1),
              child: Column(
                children: [
                  // My Orders
                  ListTile(
                    title: Text("My Orders"),
                    trailing: Icon(Icons.chevron_right, color: Colors.green),
                  ),
                  // Saved Addresses
                  ListTile(
                    title: Text("Saved Addresses"),
                    trailing: Icon(Icons.chevron_right, color: Colors.green),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),

            // Edit Profile
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
                backgroundColor: Colors.green,
              ),
              child: Text(
                "Log Out",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}