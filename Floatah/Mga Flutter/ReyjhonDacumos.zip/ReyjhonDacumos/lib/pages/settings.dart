import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            // Title
            Text(
              "Settings",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),

            SizedBox(height: 24),

            // Account section
            Text(
              "Account",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              color: Color.fromRGBO(232, 245, 233, 1),
              child: Column(
                children: [
                  // Account Settings
                  ListTile(
                    title: Text("Account Settings"),
                    trailing: Icon(Icons.chevron_right, color: Colors.green),
                  ),
                  // Privacy
                  ListTile(
                    title: Text("Privacy"),
                    trailing: Icon(Icons.chevron_right, color: Colors.green),
                  ),
                ],
              ),
            ),

            SizedBox(height: 24),

            // Preferences section
            Text(
              "Preferences",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Container(
              color: Color.fromRGBO(232, 245, 233, 1),
              child: Column(
                children: [
                  // Notifications
                  ListTile(
                    title: Text("Notifications"),
                    trailing: Switch(
                      value: true,
                      onChanged: (_) {},
                      activeThumbColor: Colors.green,
                    ),
                  ),
                  // Dark Mode
                  ListTile(
                    title: Text("Dark Mode"),
                    trailing: Switch(
                      value: false,
                      onChanged: (_) {},
                      activeThumbColor: Colors.green,
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),

            // Log Out
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
                backgroundColor: Colors.green,
              ),
              child: Text(
                "Log Out",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}