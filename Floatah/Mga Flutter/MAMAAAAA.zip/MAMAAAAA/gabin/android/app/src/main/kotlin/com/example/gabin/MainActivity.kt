package com.example.gabin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
