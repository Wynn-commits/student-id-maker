import 'package:flutter/material.dart';

class SettingsSection extends StatelessWidget {
  const SettingsSection({super.key});

@override
  Widget build(BuildContext context) {
    final items = const [
      (Icons.person_outline, 'Account'),
      (Icons.lock_outline, 'Privacy & Security'),
      (Icons.notifications_none, 'Notifications'),
      (Icons.language, 'Language'),
      (Icons.dark_mode_outlined, 'Appearance'),
      (Icons.help_outline, 'Help & Support'),
      (Icons.logout, 'Log Out'),
    ];

return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'Settings',
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: Colors.grey.shade300),
            ),
            child: Column(
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  SettingTile(icon: items[i].$1, title: items[i].$2),
                  if (i != items.length - 1)
                    const Divider(height: 1, indent: 56),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SettingTile extends StatelessWidget {
  final IconData icon;
  final String title;

const SettingTile({super.key, required this.icon, required this.title});

@override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.deepPurple),
      title: Text(title),
      trailing: const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$title tapped')),
        );
      },
    );
  }
}
