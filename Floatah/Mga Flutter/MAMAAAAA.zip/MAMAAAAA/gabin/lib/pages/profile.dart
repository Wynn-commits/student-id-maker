import 'package:flutter/material.dart';

class ProfileSection extends StatelessWidget {
  const ProfileSection({super.key});

@override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 24),
        const CircleAvatar(
          radius: 56,
          backgroundColor: Colors.deepPurple,
          backgroundImage: NetworkImage(
            'assets/123.jpg', // replace with your image
          ),
          child: Align(
            alignment: Alignment.bottomRight,
            child: CircleAvatar(
              radius: 16,
              backgroundColor: Colors.white,
              child: Icon(Icons.edit, size: 16, color: Colors.deepPurple),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Gabin Calumba',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          'Flutter Developer • Pilipins',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          'Jabai Developer',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: const [
            StatCard(count: '24', label: 'Projects'),
            StatCard(count: '1.2K', label: 'Followers'),
            StatCard(count: '320', label: 'Following'),
          ],
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String count;
  final String label;

const StatCard({super.key, required this.count, required this.label});

@override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(count,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      ],
    );
  }
}
