import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/profile.dart';
import 'package:flutter_application_1/pages/settings.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BaiPage'),
        centerTitle: true,
        actions: const [
          Icon(Icons.notifications_outlined),
          SizedBox(width: 12),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: const [
            ProfileSection(),
            SettingsSection(),
            SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
