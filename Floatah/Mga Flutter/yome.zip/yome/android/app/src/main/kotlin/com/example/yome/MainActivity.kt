package com.example.yome

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
