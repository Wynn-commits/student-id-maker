import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
       return Scaffold(
      body: Center(
        child: Column(
          children: [
            CircleAvatar(
              radius: 100,
              backgroundImage: AssetImage("../assets/yome.jpg"),
            ),
            Text("Mayome Panunciar", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
            Text("Age: 20", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            Text("Address: Brgy. Palampas", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)
          ],
        ),
      ),
    );
  }
}