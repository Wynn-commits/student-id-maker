import 'package:flutter/material.dart';
import 'package:yome/pages/home.dart';
import 'package:yome/pages/profile.dart';
import 'package:yome/pages/settings.dart';

class IndexPage extends StatefulWidget {
  const IndexPage ({super.key});

  @override
  State<IndexPage> createState() => _IndexPageState();
}

class _IndexPageState extends State<IndexPage> {
  int _selectedIndex = 0;

  void bottomnavbarTapped(int index){
    setState(() {
      _selectedIndex = index;
    });
  
  }

  final List _pages = [
    HomePage(),

    SettingsPage(),

    ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        centerTitle: true,
        title: Text("yome page", style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),),
        actions: [IconButton(onPressed: (){}, icon: Icon(Icons.notifications))],
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: bottomnavbarTapped,
        items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "home"),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: "settings"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "profile"),
      ]),

      body: _pages[_selectedIndex],
    );
  }
}