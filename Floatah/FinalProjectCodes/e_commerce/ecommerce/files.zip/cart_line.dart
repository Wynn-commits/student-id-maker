import 'product.dart';

/// One row in the cart: a product and how many of it the user wants.
/// (Hive only stores productId -> quantity; the product is looked up.)
class CartLine {
  final Product product;
  final int quantity;

  CartLine({required this.product, required this.quantity});

  double get subtotal => product.price * quantity;
}
