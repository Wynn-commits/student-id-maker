import 'package:flutter/material.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/mybuttons.dart';

// One order in the order history.
class OrderTile extends StatelessWidget {
  final String orderNo;
  final String date;
  final String status; // "Placed", "Delivered" or "Cancelled"
  final List items;
  final double total;
  final String payment;
  final String customer;
  final String address;
  final VoidCallback onDelivered;
  final VoidCallback onCancel;
  final VoidCallback onDelete;

  OrderTile({
    super.key,
    required this.orderNo,
    required this.date,
    required this.status,
    required this.items,
    required this.total,
    required this.payment,
    required this.customer,
    required this.address,
    required this.onDelivered,
    required this.onCancel,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    MaterialColor statusColor = Colors.orange;
    if (status == "Delivered") statusColor = Colors.green;
    if (status == "Cancelled") statusColor = Colors.red;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // order number + status
            Row(
              children: [
                Expanded(
                  child: Text(orderNo, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.shade100,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: statusColor.shade900,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 2),
            Text(date, style: TextStyle(fontSize: 12, color: Colors.black54)),
            Divider(height: 24),

            // the products in this order
            for (final item in items)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        "${item['quantity']} x ${item['name']}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(formatPrice((item["price"] as num) * (item["quantity"] as int))),
                  ],
                ),
              ),
            Divider(height: 24),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Total", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text(
                  formatPrice(total),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange.shade900,
                  ),
                ),
              ],
            ),
            SizedBox(height: 6),
            Text("Paid by: $payment", style: TextStyle(fontSize: 12, color: Colors.black54)),
            Text("Deliver to: $customer, $address", style: TextStyle(fontSize: 12, color: Colors.black54)),
            SizedBox(height: 8),

            // buttons: only a "Placed" order can still be delivered or cancelled
            // Wrap moves a button to the next line if the screen is too narrow
            Wrap(
              alignment: WrapAlignment.end,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: 8,
              children: [
                if (status == "Placed") ...[
                  MyButtons(text: "Cancel order", color: Colors.red.shade100, textColor: Colors.red.shade900, onPressed: onCancel),
                  MyButtons(text: "Mark delivered", color: Colors.green.shade600, textColor: Colors.white, onPressed: onDelivered),
                ],
                IconButton(
                  tooltip: "Delete order",
                  onPressed: onDelete,
                  icon: Icon(Icons.delete_outline, color: Colors.red.shade600),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
