import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/pages/productdetailpage.dart';
import 'package:yconpractice/utils/emptystate.dart';
import 'package:yconpractice/utils/productcard.dart';
import 'package:yconpractice/utils/shopdata.dart';

class FavoritesPage extends StatefulWidget {
  FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  final productBox = Hive.box("products");
  final favoritesBox = Hive.box("favorites");

  Future<void> openDetail(String id) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => ProductDetailPage(productId: id)),
    );
    if (!mounted) return;
    setState(() {});
  }

  Future<void> removeFavorite(String id) async {
    await toggleFavorite(id);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> addProductToCart(String id, String name) async {
    await addToCart(id);
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("$name added to cart", style: TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // the favorites box only stores ids, so we look each product up in the catalog
    final ids = favoritesBox.keys.map((key) => key.toString()).toList();
    ids.sort();

    return Scaffold(
      appBar: AppBar(title: Text("My Favorites")),
      body: ids.isEmpty
          ? EmptyState(
              icon: Icons.favorite_border,
              message: "No favorites yet.\nTap the heart on a product to save it here.",
            )
          : GridView.builder(
              padding: EdgeInsets.all(16),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 0.68,
              ),
              itemCount: ids.length,
              itemBuilder: (context, index) {
                final id = ids[index];
                final p = productBox.get(id);

                return ProductCard(
                  name: "${p['name']}",
                  category: "${p['category']}",
                  price: (p["price"] as num).toDouble(),
                  isFavorite: true,
                  onTap: () => openDetail(id),
                  onFavorite: () => removeFavorite(id),
                  onAddToCart: () => addProductToCart(id, "${p['name']}"),
                );
              },
            ),
    );
  }
}
