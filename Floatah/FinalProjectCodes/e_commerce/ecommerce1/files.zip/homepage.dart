import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/pages/cartpage.dart';
import 'package:yconpractice/pages/favoritespage.dart';
import 'package:yconpractice/pages/orderspage.dart';
import 'package:yconpractice/pages/productdetailpage.dart';
import 'package:yconpractice/utils/emptystate.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/productcard.dart';
import 'package:yconpractice/utils/shopdata.dart';

class Homepage extends StatefulWidget {
  Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  final productBox = Hive.box("products");
  final searchController = TextEditingController();

  String searchText = "";
  String selectedCategory = "All";
  final categories = ["All", "Gadgets", "Fashion", "Home", "Snacks", "Sports"];

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  // Open another page, and refresh this one when we come back
  // (so the cart badge and the hearts are always up to date).
  Future<void> openPage(Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (context) => page));
    if (!mounted) return;
    setState(() {});
  }

  Future<void> addProductToCart(String id, String name) async {
    await addToCart(id);
    if (!mounted) return;
    setState(() {});

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("$name added to cart", style: TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
        action: SnackBarAction(
          label: "VIEW CART",
          textColor: Colors.yellow,
          onPressed: () => openPage(CartPage()),
        ),
      ),
    );
  }

  Future<void> toggleHeart(String id) async {
    await toggleFavorite(id);
    if (!mounted) return;
    setState(() {});
  }

  Widget buildHeader() {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // free shipping banner
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                Icon(Icons.local_shipping, color: Colors.yellow),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "Free shipping on orders of ${formatPrice(freeShippingMinimum)} and up",
                    style: TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 12),

          // search bar
          TextField(
            controller: searchController,
            onChanged: (value) {
              setState(() {
                searchText = value;
              });
            },
            decoration: InputDecoration(
              hintText: "Search products",
              prefixIcon: Icon(Icons.search),
              suffixIcon: searchText.isEmpty
                  ? null
                  : IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () {
                        searchController.clear();
                        setState(() {
                          searchText = "";
                        });
                      },
                    ),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          SizedBox(height: 12),

          // category chips (scroll sideways)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final category in categories)
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(category),
                      selected: selectedCategory == category,
                      showCheckmark: false,
                      selectedColor: Colors.yellow,
                      backgroundColor: Colors.white,
                      onSelected: (value) {
                        setState(() {
                          selectedCategory = category;
                        });
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // keep only the products that match the category and the search text
    final items = productBox.toMap().entries.where((e) {
      final p = e.value;
      bool matchesCategory = selectedCategory == "All" || p["category"] == selectedCategory;
      final text = "${p['name']} ${p['category']}".toLowerCase();
      bool matchesSearch = text.contains(searchText.toLowerCase().trim());
      return matchesCategory && matchesSearch;
    }).toList();

    items.sort((a, b) => a.key.toString().compareTo(b.key.toString()));

    final cartCount = cartItemCount();

    return Scaffold(
      appBar: AppBar(
        title: Text("Mini Shop"),
        actions: [
          IconButton(
            tooltip: "Favorites",
            onPressed: () => openPage(FavoritesPage()),
            icon: Icon(Icons.favorite),
          ),
          IconButton(
            tooltip: "Cart",
            onPressed: () => openPage(CartPage()),
            icon: Badge(
              isLabelVisible: cartCount > 0,
              label: Text("$cartCount"),
              child: Icon(Icons.shopping_cart),
            ),
          ),
          IconButton(
            tooltip: "My orders",
            onPressed: () => openPage(OrdersPage()),
            icon: Icon(Icons.receipt_long),
          ),
        ],
      ),

      body: Column(
        children: [
          buildHeader(),
          Expanded(
            child: items.isEmpty
                ? EmptyState(icon: Icons.search_off, message: "No products found.\nTry another search or category.")
                : GridView.builder(
                    padding: EdgeInsets.fromLTRB(16, 4, 16, 24),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.68,
                    ),
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final id = items[index].key.toString();
                      final p = items[index].value;

                      return ProductCard(
                        name: "${p['name']}",
                        category: "${p['category']}",
                        price: (p["price"] as num).toDouble(),
                        isFavorite: isFavorite(id),
                        onTap: () => openPage(ProductDetailPage(productId: id)),
                        onFavorite: () => toggleHeart(id),
                        onAddToCart: () => addProductToCart(id, "${p['name']}"),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
