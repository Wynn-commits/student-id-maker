import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/mybuttons.dart';
import 'package:yconpractice/utils/shopdata.dart';

class ProductDetailPage extends StatefulWidget {
  final String productId;

  ProductDetailPage({super.key, required this.productId});

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  int quantity = 1;

  Future<void> toggleHeart() async {
    await toggleFavorite(widget.productId);
    if (!mounted) return;
    setState(() {});
  }

  Future<void> addProductToCart(String name) async {
    await addToCart(widget.productId, quantity: quantity);
    if (!mounted) return;

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("$quantity x $name added to cart", style: TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
    setState(() {
      quantity = 1;
    });
  }

  // the round + and - buttons
  Widget stepButton(IconData icon, VoidCallback onPressed) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(color: Colors.yellow, shape: BoxShape.circle),
        child: Icon(icon, size: 22),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final product = Hive.box("products").get(widget.productId);
    final String name = "${product['name']}";
    final String category = "${product['category']}";
    final double price = (product["price"] as num).toDouble();
    bool favorite = isFavorite(widget.productId);

    return Scaffold(
      appBar: AppBar(
        title: Text("Product Details"),
        actions: [
          IconButton(
            tooltip: "Favorite",
            onPressed: toggleHeart,
            icon: Icon(
              favorite ? Icons.favorite : Icons.favorite_border,
              color: favorite ? Colors.red : Colors.black87,
            ),
          ),
        ],
      ),

      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: [
                // big picture area
                Container(
                  height: 220,
                  width: double.infinity,
                  color: categoryColor(category),
                  child: Icon(categoryIcon(category), size: 110, color: Colors.black45),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.yellow,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(category, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                      SizedBox(height: 12),
                      Text(name, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                      SizedBox(height: 6),
                      Text(
                        formatPrice(price),
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange.shade900,
                        ),
                      ),
                      SizedBox(height: 16),
                      Text("Description", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      SizedBox(height: 6),
                      Text(
                        "${product['description']}",
                        style: TextStyle(fontSize: 15, color: Colors.black87, height: 1.4),
                      ),
                      SizedBox(height: 24),
                      Text("Quantity", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          stepButton(Icons.remove, () {
                            if (quantity > 1) {
                              setState(() {
                                quantity--;
                              });
                            }
                          }),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              "$quantity",
                              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                          ),
                          stepButton(Icons.add, () {
                            if (quantity < 99) {
                              setState(() {
                                quantity++;
                              });
                            }
                          }),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // bottom bar: total price + add to cart button
          Container(
            padding: EdgeInsets.fromLTRB(20, 14, 20, 20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              boxShadow: [
                BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -3)),
              ],
            ),
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Total", style: TextStyle(fontSize: 12, color: Colors.black54)),
                    Text(
                      formatPrice(price * quantity),
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                SizedBox(width: 20),
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: MyButtons(
                      text: "Add to Cart",
                      color: Colors.yellow,
                      onPressed: () => addProductToCart(name),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
