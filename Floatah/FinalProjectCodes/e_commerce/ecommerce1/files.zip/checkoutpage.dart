import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/mybuttons.dart';
import 'package:yconpractice/utils/shopdata.dart';
import 'package:yconpractice/utils/summaryrow.dart';

class CheckoutPage extends StatefulWidget {
  CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();

  final payments = ["Cash on Delivery", "E-Wallet (simulated)", "Card (simulated)"];
  String selectedPayment = "Cash on Delivery";

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    addressController.dispose();
    super.dispose();
  }

  // ---- validators: return an error message, or null when the value is OK ----

  String? checkName(String? value) {
    if (value == null || value.trim().length < 2) {
      return "Enter your full name";
    }
    return null;
  }

  String? checkPhone(String? value) {
    final text = (value ?? "").trim();
    if (text.isEmpty) {
      return "Enter your phone number";
    }
    if (!RegExp(r"^[0-9]{10,13}$").hasMatch(text)) {
      return "Use 10 to 13 digits, numbers only";
    }
    return null;
  }

  String? checkAddress(String? value) {
    if (value == null || value.trim().length < 5) {
      return "Enter your complete address";
    }
    return null;
  }

  InputDecoration fieldDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    );
  }

  Future<void> placeOrder() async {
    // stop here if any field has an error
    if (!formKey.currentState!.validate()) {
      return;
    }

    final cartBox = Hive.box("cart");
    final productBox = Hive.box("products");

    // copy the cart into a list of order lines
    final lines = [];
    for (final key in cartBox.keys) {
      final p = productBox.get(key);
      lines.add({
        "name": p["name"],
        "price": p["price"],
        "quantity": cartBox.get(key),
      });
    }
    if (lines.isEmpty) {
      return;
    }

    final subtotal = cartSubtotal();
    final shipping = shippingFor(subtotal);
    final number = DateTime.now().millisecondsSinceEpoch % 1000000;
    final orderNo = "ORD-${number.toString().padLeft(6, '0')}";

    // save the order, then empty the cart
    await Hive.box("orders").add({
      "orderNo": orderNo,
      "date": DateTime.now().toIso8601String(),
      "items": lines,
      "total": subtotal + shipping,
      "customer": nameController.text.trim(),
      "phone": phoneController.text.trim(),
      "address": addressController.text.trim(),
      "payment": selectedPayment,
      "status": "Placed",
    });
    await cartBox.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.yellow,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.check_circle, size: 70, color: Colors.green.shade700),
              SizedBox(height: 12),
              Text("Order placed!", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 6),
              Text(orderNo, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text(
                "This is a simulated order. No real payment was made.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13),
              ),
              SizedBox(height: 16),
              MyButtons(
                text: "Back to shop",
                color: Colors.black87,
                textColor: Colors.white,
                // go all the way back to the first page (the shop)
                onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartBox = Hive.box("cart");
    final productBox = Hive.box("products");
    final subtotal = cartSubtotal();
    final shipping = shippingFor(subtotal);

    return Scaffold(
      appBar: AppBar(title: Text("Checkout")),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // order summary
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Order summary", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                for (final key in cartBox.keys)
                  SummaryRow(
                    label: "${cartBox.get(key)} x ${productBox.get(key)['name']}",
                    value: formatPrice((productBox.get(key)["price"] as num) * (cartBox.get(key) as int)),
                  ),
                Divider(height: 20),
                SummaryRow(label: "Subtotal", value: formatPrice(subtotal)),
                SummaryRow(label: "Shipping", value: shipping == 0 ? "FREE" : formatPrice(shipping)),
                Divider(height: 20),
                SummaryRow(label: "Total", value: formatPrice(subtotal + shipping), bold: true),
              ],
            ),
          ),
          SizedBox(height: 20),

          // delivery details form
          Text("Delivery details", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Form(
            key: formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: fieldDecoration("Full name", Icons.person),
                  validator: checkName,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: fieldDecoration("Phone number", Icons.phone),
                  validator: checkPhone,
                ),
                SizedBox(height: 12),
                TextFormField(
                  controller: addressController,
                  maxLines: 2,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: fieldDecoration("Complete address", Icons.home),
                  validator: checkAddress,
                ),
              ],
            ),
          ),
          SizedBox(height: 20),

          // payment method
          Text("Payment method", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              for (final payment in payments)
                ChoiceChip(
                  label: Text(payment),
                  selected: selectedPayment == payment,
                  showCheckmark: false,
                  selectedColor: Colors.yellow,
                  backgroundColor: Colors.white,
                  onSelected: (value) {
                    setState(() {
                      selectedPayment = payment;
                    });
                  },
                ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            "Demo only: please use made-up details, not your real information.",
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
          SizedBox(height: 20),

          SizedBox(
            height: 52,
            child: MyButtons(
              text: "Place Order  |  ${formatPrice(subtotal + shipping)}",
              color: Colors.black87,
              textColor: Colors.white,
              onPressed: placeOrder,
            ),
          ),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}
