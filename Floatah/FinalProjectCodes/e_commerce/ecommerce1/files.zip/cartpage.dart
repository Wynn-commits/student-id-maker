import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/pages/checkoutpage.dart';
import 'package:yconpractice/utils/carttile.dart';
import 'package:yconpractice/utils/dialogbox.dart';
import 'package:yconpractice/utils/emptystate.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/mybuttons.dart';
import 'package:yconpractice/utils/shopdata.dart';
import 'package:yconpractice/utils/summaryrow.dart';

class CartPage extends StatefulWidget {
  CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final cartBox = Hive.box("cart");
  final productBox = Hive.box("products");

  Future<void> changeQuantity(String id, int newQuantity) async {
    await cartBox.put(id, newQuantity);
    if (!mounted) return;
    setState(() {});
  }

  // pressing "-" on the last item asks before removing it
  void decrease(String id, String name, int quantity) {
    if (quantity > 1) {
      changeQuantity(id, quantity - 1);
    } else {
      askRemove(id, name);
    }
  }

  void askRemove(String id, String name) {
    confirmDialog(
      context,
      title: "Remove item?",
      message: "Remove \"$name\" from your cart?",
      confirmText: "Remove",
      onConfirm: () async {
        await cartBox.delete(id);
        if (!mounted) return;
        setState(() {});
      },
    );
  }

  void askClearCart() {
    confirmDialog(
      context,
      title: "Clear cart?",
      message: "Remove all items from your cart?",
      confirmText: "Clear",
      onConfirm: () async {
        await cartBox.clear();
        if (!mounted) return;
        setState(() {});
      },
    );
  }

  Future<void> goToCheckout() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (context) => CheckoutPage()));
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final entries = cartBox.toMap().entries.toList();
    entries.sort((a, b) => a.key.toString().compareTo(b.key.toString()));

    final subtotal = cartSubtotal();
    final shipping = shippingFor(subtotal);

    return Scaffold(
      appBar: AppBar(
        title: Text("My Cart"),
        actions: [
          if (entries.isNotEmpty)
            IconButton(
              tooltip: "Clear cart",
              onPressed: askClearCart,
              icon: Icon(Icons.delete_sweep),
            ),
        ],
      ),
      body: entries.isEmpty
          ? EmptyState(
              icon: Icons.shopping_cart_outlined,
              message: "Your cart is empty.\nGo back and add something you like!",
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    itemCount: entries.length,
                    itemBuilder: (context, index) {
                      final id = entries[index].key.toString();
                      final int quantity = entries[index].value;
                      final p = productBox.get(id);
                      final String name = "${p['name']}";

                      return CartTile(
                        name: name,
                        category: "${p['category']}",
                        price: (p["price"] as num).toDouble(),
                        quantity: quantity,
                        onIncrease: () => changeQuantity(id, quantity + 1),
                        onDecrease: () => decrease(id, name, quantity),
                        onDelete: () => askRemove(id, name),
                      );
                    },
                  ),
                ),

                // price summary + checkout button
                Container(
                  padding: EdgeInsets.fromLTRB(20, 16, 20, 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [
                      BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -3)),
                    ],
                  ),
                  child: Column(
                    children: [
                      SummaryRow(label: "Items", value: "${cartItemCount()}"),
                      SummaryRow(label: "Subtotal", value: formatPrice(subtotal)),
                      SummaryRow(
                        label: "Shipping",
                        value: shipping == 0 ? "FREE" : formatPrice(shipping),
                      ),
                      if (shipping > 0)
                        Padding(
                          padding: EdgeInsets.only(top: 2),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Add ${formatPrice(freeShippingMinimum - subtotal)} more for free shipping",
                              style: TextStyle(fontSize: 12, color: Colors.orange.shade900),
                            ),
                          ),
                        ),
                      Divider(height: 20),
                      SummaryRow(label: "Total", value: formatPrice(subtotal + shipping), bold: true),
                      SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: MyButtons(
                          text: "Checkout",
                          color: Colors.yellow,
                          onPressed: goToCheckout,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
