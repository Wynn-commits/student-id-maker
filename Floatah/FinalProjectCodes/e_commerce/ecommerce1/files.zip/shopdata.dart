import 'package:hive_ce_flutter/hive_flutter.dart';

// All the small Hive actions the pages share, kept in one place.

double shippingFee = 50;
double freeShippingMinimum = 1000;

// ----- cart -----

Future<void> addToCart(String id, {int quantity = 1}) async {
  final cartBox = Hive.box("cart");
  int current = cartBox.get(id, defaultValue: 0);
  await cartBox.put(id, current + quantity);
}

// total number of items (3 mugs + 1 cap = 4)
int cartItemCount() {
  int total = 0;
  for (final quantity in Hive.box("cart").values) {
    total += quantity as int;
  }
  return total;
}

double cartSubtotal() {
  final cartBox = Hive.box("cart");
  final productBox = Hive.box("products");

  double total = 0;
  for (final key in cartBox.keys) {
    final product = productBox.get(key);
    if (product != null) {
      total += (product["price"] as num) * (cartBox.get(key) as int);
    }
  }
  return total;
}

// free shipping when the subtotal is high enough (or the cart is empty)
double shippingFor(double subtotal) {
  if (subtotal == 0 || subtotal >= freeShippingMinimum) {
    return 0;
  }
  return shippingFee;
}

// ----- favorites -----

bool isFavorite(String id) {
  return Hive.box("favorites").containsKey(id);
}

Future<void> toggleFavorite(String id) async {
  final favoritesBox = Hive.box("favorites");
  if (favoritesBox.containsKey(id)) {
    await favoritesBox.delete(id);
  } else {
    await favoritesBox.put(id, true);
  }
}
