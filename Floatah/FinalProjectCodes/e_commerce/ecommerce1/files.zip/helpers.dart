import 'package:flutter/material.dart';

// 1299.5 becomes "₱1,299.50"
String formatPrice(num amount) {
  final fixed = amount.toStringAsFixed(2);
  final parts = fixed.split(".");
  final whole = parts[0];

  String withCommas = "";
  for (int i = 0; i < whole.length; i++) {
    // put a comma before every group of 3 digits
    if (i > 0 && (whole.length - i) % 3 == 0) {
      withCommas += ",";
    }
    withCommas += whole[i];
  }
  return "₱$withCommas.${parts[1]}";
}

// "2026-10-28T14:30:00.000" becomes "2026-10-28 14:30"
String formatDate(String iso) {
  return iso.substring(0, 16).replaceFirst("T", " ");
}

// The catalog has no photos, so each category gets its own icon and color.
IconData categoryIcon(String category) {
  if (category == "Gadgets") return Icons.headphones;
  if (category == "Fashion") return Icons.checkroom;
  if (category == "Home") return Icons.chair;
  if (category == "Snacks") return Icons.fastfood;
  if (category == "Sports") return Icons.sports_basketball;
  return Icons.shopping_bag;
}

Color categoryColor(String category) {
  if (category == "Gadgets") return Colors.blue.shade100;
  if (category == "Fashion") return Colors.pink.shade100;
  if (category == "Home") return Colors.orange.shade100;
  if (category == "Snacks") return Colors.green.shade100;
  if (category == "Sports") return Colors.purple.shade100;
  return Colors.grey.shade200;
}
