import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/utils/dialogbox.dart';
import 'package:yconpractice/utils/emptystate.dart';
import 'package:yconpractice/utils/helpers.dart';
import 'package:yconpractice/utils/ordertile.dart';

class OrdersPage extends StatefulWidget {
  OrdersPage({super.key});

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  final orderBox = Hive.box("orders");

  void showMessage(String text) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, style: TextStyle(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
  }

  // UPDATE: change the status of an order
  Future<void> updateStatus(dynamic key, String status) async {
    final order = Map.from(orderBox.get(key)); // a copy we can change
    order["status"] = status;
    await orderBox.put(key, order);

    if (!mounted) return;
    setState(() {});
    showMessage("Order marked as $status");
  }

  void askCancel(dynamic key, String orderNo) {
    confirmDialog(
      context,
      title: "Cancel order?",
      message: "Cancel order $orderNo?",
      confirmText: "Cancel order",
      onConfirm: () => updateStatus(key, "Cancelled"),
    );
  }

  // DELETE: remove an order from the history
  void askDelete(dynamic key, String orderNo) {
    confirmDialog(
      context,
      title: "Delete order?",
      message: "Delete $orderNo from your history? This cannot be undone.",
      confirmText: "Delete",
      onConfirm: () async {
        await orderBox.delete(key);
        if (!mounted) return;
        setState(() {});
        showMessage("$orderNo deleted");
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // keys count up (0, 1, 2...), so reversed = newest order first
    final entries = orderBox.toMap().entries.toList().reversed.toList();

    return Scaffold(
      appBar: AppBar(title: Text("My Orders")),
      body: entries.isEmpty
          ? EmptyState(
              icon: Icons.receipt_long_outlined,
              message: "No orders yet.\nYour placed orders will show up here.",
            )
          : ListView.builder(
              padding: EdgeInsets.symmetric(vertical: 8),
              itemCount: entries.length,
              itemBuilder: (context, index) {
                final key = entries[index].key;
                final o = entries[index].value;

                return OrderTile(
                  orderNo: "${o['orderNo']}",
                  date: formatDate("${o['date']}"),
                  status: "${o['status']}",
                  items: o["items"] as List,
                  total: (o["total"] as num).toDouble(),
                  payment: "${o['payment']}",
                  customer: "${o['customer']}",
                  address: "${o['address']}",
                  onDelivered: () => updateStatus(key, "Delivered"),
                  onCancel: () => askCancel(key, "${o['orderNo']}"),
                  onDelete: () => askDelete(key, "${o['orderNo']}"),
                );
              },
            ),
    );
  }
}
