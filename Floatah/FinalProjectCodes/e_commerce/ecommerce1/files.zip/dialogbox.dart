import 'package:flutter/material.dart';
import 'package:yconpractice/utils/mybuttons.dart';

// A yellow "are you sure?" dialog, used for deleting, cancelling and clearing.
class DialogBox extends StatelessWidget {
  final String title;
  final String message;
  final String confirmText;
  final Color confirmColor;
  final VoidCallback onConfirm;
  final VoidCallback onCancel;

  DialogBox({
    super.key,
    required this.title,
    required this.message,
    required this.confirmText,
    required this.confirmColor,
    required this.onConfirm,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.yellow,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          Text(message),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              MyButtons(
                text: confirmText,
                color: confirmColor,
                textColor: Colors.white,
                onPressed: onConfirm,
              ),
              SizedBox(width: 10),
              MyButtons(text: "Cancel", onPressed: onCancel),
            ],
          ),
        ],
      ),
    );
  }
}

// A shortcut so every page can open the dialog in one line.
// The dialog closes first, then onConfirm runs.
void confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmText,
  required VoidCallback onConfirm,
  Color confirmColor = Colors.red,
}) {
  showDialog(
    context: context,
    builder: (context) {
      return DialogBox(
        title: title,
        message: message,
        confirmText: confirmText,
        confirmColor: confirmColor,
        onConfirm: () {
          Navigator.of(context).pop();
          onConfirm();
        },
        onCancel: () => Navigator.of(context).pop(),
      );
    },
  );
}
