import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:yconpractice/pages/homepage.dart';
import 'package:yconpractice/utils/sampledata.dart';

// Start Hive and open every box BEFORE runApp so the pages can read saved data.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox("products"); // the catalog
  await Hive.openBox("cart"); // product id -> quantity
  await Hive.openBox("favorites"); // product id -> true
  await Hive.openBox("orders"); // simulated orders (order history)

  // First time the app runs the catalog is empty, so fill it with sample products.
  final productBox = Hive.box("products");
  if (productBox.isEmpty) {
    for (final product in sampleProducts) {
      await productBox.put(product["id"], product);
    }
  }

  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Mini Shop",
      home: Homepage(),
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.yellow),
        scaffoldBackgroundColor: Colors.yellow[100],
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.yellow,
          foregroundColor: Colors.black87,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
