# Student Attendance System — event-based admin dashboard

```
student-attendance-system/
├── backend/           Express API — students, kiosk scanning, admin + event control
├── kiosk/              Student-facing app (was "frontend") — registration + scanning
└── admin-dashboard/    Staff-only app (was "admin") — event control + attendance report
```

Renamed both frontend folders so nothing reads as similar: `kiosk` is what students
touch, `admin-dashboard` is what staff touch. Update any shortcuts/scripts you had
pointing at the old `frontend/`/`admin/` paths.

## What changed: attendance is now per-event, not per-date

Previously a scan just logged whatever time it happened at, for "today." Now
scanning only does anything while an admin has an event open, and what a scan
*does* depends on which phase the admin has opened:

```
not started ──[Start time-in]──> time-in open ──[Start time-out]──> time-out open ──[End event]──> ended
```

- **Time-in open** — scanning creates a time-in record. Scanning again just
  says "already logged in" — it can't also grab a time-out, because time-out
  isn't open yet.
- **Time-out open** — scanning closes out an *existing* time-in. A student
  with no time-in record can't scan their way into one; they get "no time-in
  record found."
- **Ended** — scanning is closed entirely. Anyone still showing "timed in
  only" in the report genuinely didn't log out — that's your sanction list.

This is what makes the two-scan trick (scan once immediately, then scan again
seconds later, to fake a full day's attendance) impossible: the two actions
are only reachable in two separate, admin-controlled windows.

## 1. Update the database

`attendance_logs` and `sanction_flags` now key off `event_id` instead of
`log_date`. Run the migration once against your existing database:

```bash
mysql -u root -p attendance_system < backend/migrate_to_events.sql
```

This drops and recreates just those two tables — any test scans you already
made won't carry forward, but `students`, `enrollment_masterlist`, and
`admins` (and all their data) are untouched. `backend/schema.sql` has also
been updated to the same structure, for anyone setting up fresh.

A ready-to-use admin account is now seeded automatically — see below.

## 2. Run everything

No new dependencies this time — same install as before.

```bash
# terminal 1
cd backend && npm install && npm run dev

# terminal 2 — student kiosk
cd kiosk && npm install && npm run dev          # http://localhost:5173

# terminal 3 — admin dashboard
cd admin-dashboard && npm install && copy .env.example .env && npm run dev   # http://localhost:5174
```

(If you already have an admin account from before, it still works — accounts
weren't touched by the migration.)

**Log in with:**
- username: `admin`
- password: `vLfMnP56oeUS`

This account is seeded by `backend/schema.sql` on a fresh install. If you're
running this against your existing database instead, load it directly:

```bash
mysql -u root -p attendance_system < backend/seed_admin.sql
```

Change the password after your first login:

```bash
node scripts/resetAdminPassword.js admin "your-new-password"
```

## 3. Running an event

There are three shapes an event can take, chosen by which button you press
while it's still "not started":

**Full flow — log both arrival and departure**
1. Create an event, then click **Start time-in**. The kiosk shows "Time-In is
   open" and accepts scans.
2. When it's time, click **Start time-out**. The kiosk switches to "Time-Out
   is open." Students who already timed in can now scan to time out.
3. Click **End event**. The report now treats every remaining "timed in
   only" row as flaggable — they genuinely didn't log out.

**Time-in only — just an arrival record**
1. Create an event, click **Start time-in**.
2. When done, click **End event early** instead of ever opening time-out.
   The report marks anyone with a time-in as complete — it won't ask them
   to have logged out, since that was never part of this event.

**Time-out only — just a departure record, no arrival check**
1. Create an event, click **Start time-out only** right away (skipping
   time-in entirely). The kiosk shows "Time-Out is open" immediately.
2. A scan creates a fresh time-out record on the spot — no prior time-in is
   required or possible for this event.
3. Click **End event** when done. Anyone who never scanned shows as having
   no log, same as any other flagging case.

The kiosk polls for the active event every few seconds, so it picks up phase
changes on its own — no refresh needed, though a scan attempt also re-checks
immediately after.

## Where the "no two-scan trick" logic actually lives

`backend/routes/attendance.js` — the `/api/attendance/scan` endpoint decides
what a scan does purely from the *event's* current status and how it was
opened, never from anything the request itself claims. There's no
`type: "time-in"` field a student could send to force one outcome or the
other. A time-out can only ever do one of two things: close an existing
time-in, or (only when the event was deliberately opened as time-out-only)
create a fresh time-out-only record — it can never create a backdated
time-in to go with it.

## Access control (unchanged from before)

- `backend/middleware/requireAdmin.js` still guards every `/api/admin/*`
  route, including the new event controls — a valid admin token is required
  regardless of what the frontend sends.
- `GET /api/events/active` is the one intentionally public endpoint — the
  kiosk needs to know the current phase before anyone has logged in.
- Admin accounts are still only created via `npm run create-admin -- username
  password "Name"` — no sign-up screen.
