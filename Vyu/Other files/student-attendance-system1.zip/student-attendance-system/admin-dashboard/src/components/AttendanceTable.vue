<template>
  <table class="attendance-table">
    <thead>
      <tr>
        <th>Student no.</th>
        <th>Name</th>
        <th>Section</th>
        <th>Time in</th>
        <th>Time out</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="row in rows" :key="row.id">
        <td class="mono">{{ row.student_number }}</td>
        <td>{{ row.name }}</td>
        <td class="muted">{{ row.year_section }}</td>
        <td :class="{ muted: !row.time_in }">{{ formatTime(row.time_in) }}</td>
        <td :class="{ muted: !row.time_out }">{{ formatTime(row.time_out) }}</td>
        <td>
          <span v-if="row.status === 'complete'" class="badge badge-success">Complete</span>
          <span v-else-if="row.status === 'partial' && !eventEnded" class="badge badge-neutral">Timed in — event ongoing</span>
          <button
            v-else-if="row.status === 'partial'"
            class="flag-btn"
            :class="{ flagged: row.flagged }"
            @click="$emit('toggle-flag', row)"
          >
            {{ row.flagged ? 'Flagged — did not log out' : 'Flag — did not log out' }}
          </button>
          <span v-else-if="!eventEnded" class="badge badge-neutral">No log yet</span>
          <button
            v-else
            class="flag-btn"
            :class="{ flagged: row.flagged }"
            @click="$emit('toggle-flag', row)"
          >
            {{ row.flagged ? 'Flagged' : 'Flag' }}
          </button>
        </td>
      </tr>
    </tbody>
  </table>
  <p v-if="rows.length === 0" class="empty-state">No students match this filter.</p>
</template>

<script setup>
defineProps({
  rows: { type: Array, required: true },
  // While the event is still running, "no time-out yet" is expected, not a
  // problem — so flagging only becomes available once it's ended.
  eventEnded: { type: Boolean, default: false },
});
defineEmits(['toggle-flag']);

function formatTime(value) {
  if (!value) return '—';
  return new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
</script>

<style scoped>
.attendance-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}
.attendance-table th {
  text-align: left;
  padding: 0.6rem 0.5rem;
  color: var(--color-text-muted);
  font-weight: 600;
  border-bottom: 1px solid var(--color-border);
}
.attendance-table td {
  padding: 0.6rem 0.5rem;
  border-bottom: 1px solid var(--color-border);
}
.mono {
  font-family: 'Courier New', monospace;
  font-size: 0.85rem;
}
.muted {
  color: var(--color-text-muted);
}
.badge {
  display: inline-flex;
  align-items: center;
  font-size: 0.78rem;
  font-weight: 600;
  padding: 0.2rem 0.6rem;
  border-radius: 999px;
}
.badge-success {
  background: rgba(61, 139, 125, 0.12);
  color: var(--color-accent);
}
.badge-warning {
  background: rgba(198, 138, 30, 0.12);
  color: var(--color-warning);
}
.badge-neutral {
  background: rgba(107, 114, 128, 0.12);
  color: var(--color-text-muted);
}
.flag-btn {
  border: 1px solid var(--color-danger);
  background: rgba(192, 57, 43, 0.08);
  color: var(--color-danger);
  font-size: 0.78rem;
  font-weight: 600;
  padding: 0.25rem 0.65rem;
  border-radius: 6px;
  cursor: pointer;
}
.flag-btn.flagged {
  background: var(--color-danger);
  color: #fff;
}
.empty-state {
  text-align: center;
  color: var(--color-text-muted);
  padding: 2rem 0;
  font-size: 0.9rem;
}
</style>
