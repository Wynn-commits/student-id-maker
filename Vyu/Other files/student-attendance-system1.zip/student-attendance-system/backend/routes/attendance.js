import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// POST /api/attendance/scan -> the only scan endpoint, but what a scan DOES
// now depends entirely on the active event's phase, not on the student's
// own history. This is what makes it impossible to scan twice in a row to
// grab both a time-in and a time-out: during time_in_open a second scan
// just finds an existing log and refuses; time-out isn't reachable until
// the admin flips the event to time_out_open.
router.post('/scan', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'No code provided.' });

  try {
    // QR/ID recognized?
    const [students] = await pool.query(
      'SELECT * FROM students WHERE student_number = ? OR qr_value = ? LIMIT 1',
      [code, code]
    );
    if (students.length === 0) {
      return res.status(404).json({ error: 'Invalid QR/ID.' });
    }
    const student = students[0];

    // Is there an event currently open for scanning at all?
    const [activeEvents] = await pool.query(
      `SELECT * FROM events WHERE status IN ('time_in_open', 'time_out_open') ORDER BY id DESC LIMIT 1`
    );
    if (activeEvents.length === 0) {
      return res.status(409).json({ error: 'No event is currently open for attendance.' });
    }
    const event = activeEvents[0];

    const [logs] = await pool.query(
      'SELECT * FROM attendance_logs WHERE student_id = ? AND event_id = ?',
      [student.id, event.id]
    );

    if (event.status === 'time_in_open') {
      if (logs.length > 0) {
        return res.status(409).json({
          error: 'You have already logged in for this event. Please wait for time-out to open.',
          student,
          event,
        });
      }
      const [result] = await pool.query(
        'INSERT INTO attendance_logs (student_id, event_id, time_in) VALUES (?, ?, NOW())',
        [student.id, event.id]
      );
      const [logRows] = await pool.query('SELECT * FROM attendance_logs WHERE id = ?', [result.insertId]);
      return res.json({ action: 'time-in', student, event, log: logRows[0] });
    }

    // event.status === 'time_out_open'
    if (logs.length === 0) {
      return res.status(409).json({
        error: 'No time-in record found for this event — you cannot time out.',
        student,
        event,
      });
    }
    if (logs[0].time_out) {
      return res.status(409).json({ error: 'You have already logged out for this event.', student, event });
    }
    await pool.query('UPDATE attendance_logs SET time_out = NOW() WHERE id = ?', [logs[0].id]);
    const [logRows] = await pool.query('SELECT * FROM attendance_logs WHERE id = ?', [logs[0].id]);
    return res.json({ action: 'time-out', student, event, log: logRows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
