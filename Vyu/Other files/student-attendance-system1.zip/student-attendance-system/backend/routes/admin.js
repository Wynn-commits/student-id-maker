import { Router } from 'express';
import pool from '../db.js';
import { requireAdmin } from '../middleware/requireAdmin.js';

const router = Router();

// Every route below this line requires a valid admin token.
router.use(requireAdmin);

// POST /api/admin/flag  { student_id, event_id, reason? }
// Flags (or re-flags with a new reason) a student for sanction on an event.
router.post('/flag', async (req, res) => {
  const { student_id, event_id, reason } = req.body;
  if (!student_id || !event_id) {
    return res.status(400).json({ error: 'student_id and event_id are required.' });
  }

  try {
    await pool.query(
      `INSERT INTO sanction_flags (student_id, event_id, flagged_by, reason)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE reason = VALUES(reason), flagged_by = VALUES(flagged_by), flagged_at = CURRENT_TIMESTAMP`,
      [student_id, event_id, req.admin.id, reason || null]
    );
    res.status(201).json({ message: 'Student flagged for sanction.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/admin/flag/:studentId/:eventId
router.delete('/flag/:studentId/:eventId', async (req, res) => {
  const { studentId, eventId } = req.params;
  try {
    await pool.query('DELETE FROM sanction_flags WHERE student_id = ? AND event_id = ?', [
      studentId,
      eventId,
    ]);
    res.json({ message: 'Flag removed.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/me -> lets the frontend confirm a token is still valid.
router.get('/me', (req, res) => {
  res.json({ id: req.admin.id, username: req.admin.username });
});

export default router;
