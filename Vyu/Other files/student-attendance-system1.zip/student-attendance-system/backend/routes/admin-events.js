import { Router } from 'express';
import pool from '../db.js';
import { requireAdmin } from '../middleware/requireAdmin.js';

const router = Router();

// Every route below requires a valid admin token.
router.use(requireAdmin);

// POST /api/admin/events  { name, event_date }
// Creates an event in "not_started" — scanning stays closed until the
// admin explicitly opens time-in.
router.post('/', async (req, res) => {
  const { name, event_date } = req.body;
  if (!name || !event_date) {
    return res.status(400).json({ error: 'name and event_date are required.' });
  }
  try {
    const [result] = await pool.query(
      `INSERT INTO events (name, event_date, status) VALUES (?, ?, 'not_started')`,
      [name, event_date]
    );
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/events -> most recent first, for the events list in the dashboard.
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM events ORDER BY id DESC LIMIT 50');
    res.json({ events: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/admin/events/:id/attendance -> full roster for this event, joined
// against attendance_logs and sanction_flags for THIS event only.
// Left-joined so students who never scanned at all still show up as "absent".
router.get('/:id/attendance', async (req, res) => {
  const { id } = req.params;
  try {
    const [eventRows] = await pool.query('SELECT * FROM events WHERE id = ?', [id]);
    if (eventRows.length === 0) return res.status(404).json({ error: 'Event not found.' });

    const [rows] = await pool.query(
      `SELECT
         s.id AS student_id,
         s.student_number,
         s.first_name,
         s.last_name,
         s.course,
         s.year_section,
         l.time_in,
         l.time_out,
         f.id AS flag_id,
         f.reason AS flag_reason
       FROM students s
       LEFT JOIN attendance_logs l ON l.student_id = s.id AND l.event_id = ?
       LEFT JOIN sanction_flags f ON f.student_id = s.id AND f.event_id = ?
       ORDER BY s.last_name, s.first_name`,
      [id, id]
    );

    const students = rows.map((r) => ({
      id: r.student_id,
      student_number: r.student_number,
      name: `${r.first_name} ${r.last_name}`,
      course: r.course,
      year_section: r.year_section,
      time_in: r.time_in,
      time_out: r.time_out,
      status: r.time_in && r.time_out ? 'complete' : r.time_in ? 'partial' : 'absent',
      flagged: Boolean(r.flag_id),
      flag_id: r.flag_id,
      flag_reason: r.flag_reason,
    }));

    res.json({ event: eventRows[0], students });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/events/:id/start-time-in
// Only legal from "not_started", and only one event can be open at a time —
// otherwise the kiosk's "which event is active" lookup would be ambiguous.
router.post('/:id/start-time-in', async (req, res) => {
  const { id } = req.params;
  try {
    const [openElsewhere] = await pool.query(
      `SELECT id FROM events WHERE status IN ('time_in_open', 'time_out_open') AND id != ?`,
      [id]
    );
    if (openElsewhere.length > 0) {
      return res.status(409).json({ error: 'Another event is already open. End it before starting a new one.' });
    }

    const [result] = await pool.query(
      `UPDATE events SET status = 'time_in_open', time_in_opened_at = NOW()
       WHERE id = ? AND status = 'not_started'`,
      [id]
    );
    if (result.affectedRows === 0) {
      return res.status(409).json({ error: 'This event has already been started.' });
    }
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/events/:id/start-time-out
// Only legal once time-in has been opened. From this point, a scan can
// only close out an existing time-in — it can no longer create one.
router.post('/:id/start-time-out', async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await pool.query(
      `UPDATE events SET status = 'time_out_open', time_out_opened_at = NOW()
       WHERE id = ? AND status = 'time_in_open'`,
      [id]
    );
    if (result.affectedRows === 0) {
      return res.status(409).json({ error: 'Time-in must be open before you can switch to time-out.' });
    }
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/admin/events/:id/end
// Closes scanning entirely. After this, "timed in only" in the report means
// the student genuinely didn't log out — not just that the event is ongoing.
router.post('/:id/end', async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await pool.query(
      `UPDATE events SET status = 'ended', ended_at = NOW()
       WHERE id = ? AND status IN ('time_in_open', 'time_out_open')`,
      [id]
    );
    if (result.affectedRows === 0) {
      return res.status(409).json({ error: 'This event is not currently open.' });
    }
    const [rows] = await pool.query('SELECT * FROM events WHERE id = ?', [id]);
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
