-- Run this ONCE against your existing attendance_system database to move
-- from date-based attendance to event-based attendance.
--
-- attendance_logs and sanction_flags change shape (log_date -> event_id),
-- so this drops and recreates just those two tables. Your students,
-- enrollment_masterlist, and admins tables — and all their data — are
-- untouched. Any attendance/sanction test data you scanned in before this
-- point does not carry forward; that's expected for a schema change like
-- this during development.

USE attendance_system;

DROP TABLE IF EXISTS sanction_flags;
DROP TABLE IF EXISTS attendance_logs;

CREATE TABLE IF NOT EXISTS events (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  event_date DATE NOT NULL,
  status ENUM('not_started', 'time_in_open', 'time_out_open', 'ended') NOT NULL DEFAULT 'not_started',
  time_in_opened_at DATETIME,
  time_out_opened_at DATETIME,
  ended_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE attendance_logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT NOT NULL,
  event_id INT NOT NULL,
  time_in DATETIME,
  time_out DATETIME,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (event_id) REFERENCES events(id),
  UNIQUE KEY unique_event_attendance (student_id, event_id)
);

CREATE TABLE sanction_flags (
  id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT NOT NULL,
  event_id INT NOT NULL,
  flagged_by INT NOT NULL,
  reason VARCHAR(255),
  flagged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (event_id) REFERENCES events(id),
  FOREIGN KEY (flagged_by) REFERENCES admins(id),
  UNIQUE KEY unique_flag (student_id, event_id)
);
