-- Adds the audit trail for sanction flags. Purely additive — no existing
-- table is touched, so your students, events, and current flags are safe.
-- Run once against your existing database:
--   mysql -u root -p attendance_system < backend/migrate_add_flag_history.sql

USE attendance_system;

CREATE TABLE IF NOT EXISTS sanction_flag_history (
  id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT NOT NULL,
  event_id INT NOT NULL,
  action ENUM('flagged', 'unflagged') NOT NULL,
  reason VARCHAR(255),
  performed_by INT NOT NULL,
  performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (event_id) REFERENCES events(id),
  FOREIGN KEY (performed_by) REFERENCES admins(id)
);
