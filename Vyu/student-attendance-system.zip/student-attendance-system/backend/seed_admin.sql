-- Adds one ready-to-use admin account.
--   username: admin
--   password: vLfMnP56oeUS
--
-- Run this against your EXISTING database:
--   mysql -u root -p attendance_system < backend/seed_admin.sql
--
-- Safe to re-run — it will just reset this account back to the password
-- above rather than erroring on a duplicate username.
--
-- Change this password after your first login with:
--   node scripts/resetAdminPassword.js admin "your-new-password"

USE attendance_system;

INSERT INTO admins (username, password_hash, password_salt, full_name)
VALUES (
  'admin',
  'ba8c896d67b64d8321c859f4e9763569f4d878d2ac390d4e01b9d1b1dd3450122eb81c47a52aaa82403ccc32973b757ea4cbbe51f88fdfe29ac69d9eea204a79',
  'b4f15f37da8fddc97c9afbfcfdc8951d',
  'Administrator'
)
ON DUPLICATE KEY UPDATE
  password_hash = VALUES(password_hash),
  password_salt = VALUES(password_salt),
  full_name = VALUES(full_name);
